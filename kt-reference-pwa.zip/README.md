# Kill Team Reference (Demo)
Minimal Next.js + PWA + Dexie + MiniSearch app demonstrating:
- Offline dataset with versioned manifest and incremental updates
- Client-side full-text search
- Simple rule/unit views

## Run
```bash
npm i
npm run dev
# open http://localhost:3000
```

## Build PWA
```bash
npm run build
npm start
```

## Update data
- Edit files in `public/data/v1/*.json`
- Update `version` in `public/data/v1/manifest.json`
- Optionally compute new SHA-256 for each file (the app checks integrity)
