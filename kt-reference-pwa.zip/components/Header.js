export default function Header({version, status}){
  return (
    <div className="card" style={{display:'flex',justifyContent:'space-between',alignItems:'center'}}>
      <div className="heading">
        <h1 style={{margin:0}}>Kill Team Reference <span className="badge">Demo</span></h1>
        {version && <span className="pill">Data v{version}</span>}
      </div>
      <div className="muted" style={{fontSize:'.9rem'}}>{status}</div>
    </div>
  )
}
