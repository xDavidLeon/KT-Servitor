import { useEffect, useState } from 'react'
import Header from '../components/Header'
import SearchBox from '../components/SearchBox'
import Results from '../components/Results'
import { ensureIndex } from '../lib/search'
import { checkForUpdates } from '../lib/update'
export default function Home(){
  const [q,setQ] = useState('')
  const [res,setRes] = useState(null)
  const [loading,setLoading] = useState(true)
  const [version,setVersion] = useState(null)
  const [status,setStatus] = useState('Checking for data updates…')
  useEffect(()=>{
    (async ()=>{
      const upd = await checkForUpdates()
      if (upd.error) setStatus('Offline (using cached data)')
      else setStatus(upd.updated ? 'Data updated' : 'Up to date')
      if (upd.version) setVersion(upd.version)
      const idx = await ensureIndex()
      setLoading(false)
      setRes(idx.search(q, { prefix:true, fuzzy:0.2 }))
    })()
  },[])
  useEffect(()=>{
    (async ()=>{
      const idx = await ensureIndex()
      setRes(idx.search(q, { prefix:true, fuzzy:0.2 }))
    })()
  },[q])
  return (
    <div className="container">
      <Header version={version} status={status}/>
      <SearchBox q={q} setQ={setQ}/>
      <Results results={res} loading={loading}/>
      <div className="card muted">This demo ships structured data and short summaries only; no copyrighted rule text.</div>
    </div>
  )
}
